﻿using LoadBalancer.DB.Model;

namespace LoadBalancer.DB.DAO
{
    public interface IDataSet3DAO : ICRUDDao<DataSet3, int>
    {

    }
}
