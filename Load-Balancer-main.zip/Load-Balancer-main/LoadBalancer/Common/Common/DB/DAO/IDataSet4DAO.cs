﻿using LoadBalancer.DB.Model;

namespace LoadBalancer.DB.DAO
{
    public interface IDataSet4DAO : ICRUDDao<DataSet4, int>
    {

    }
}
