﻿using Common.DB.Model;

namespace Common.DB.DAO
{
    public interface IItemLBDAO : ICRUDDaoLB<ItemLB, int>
    {
    }
}
